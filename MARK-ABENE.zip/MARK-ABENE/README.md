# MARK-ABENE

MARK-ABENE is a terminal-based video downloader script made for Termux and Linux. It supports YouTube, Facebook, Instagram, TikTok, and more.

## Usage

```bash
bash mark-abene.sh
```

Make sure you have `yt-dlp` installed.

## Features

- Download from YouTube, Facebook, Instagram, TikTok
- Easy terminal menu
- Auto-format save path

## Credits

Developed by MARK
